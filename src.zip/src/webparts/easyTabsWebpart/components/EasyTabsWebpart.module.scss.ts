/* tslint:disable */
require('./EasyTabsWebpart.module.css');
const styles = {
  easyTabsWebpart: 'easyTabsWebpart_c6a2d068',
  container: 'container_c6a2d068',
  row: 'row_c6a2d068',
  column: 'column_c6a2d068',
  'ms-Grid': 'ms-Grid_c6a2d068',
  title: 'title_c6a2d068',
  subTitle: 'subTitle_c6a2d068',
  description: 'description_c6a2d068',
  button: 'button_c6a2d068',
  label: 'label_c6a2d068',
};

export default styles;
/* tslint:enable */