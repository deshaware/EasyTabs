declare interface IEasyTabsWebpartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PropertyPaneDescription: string;
  ListFieldLabel: string;
  ItemFieldLabel: string;
  baseUrl: string;
}

declare module 'EasyTabsWebpartWebPartStrings' {
  const strings: IEasyTabsWebpartWebPartStrings;
  export = strings;
}
