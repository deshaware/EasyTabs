define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PropertyPaneDescription": "Description",
    "ListFieldLabel": "List",
    "ItemFieldLabel": "Document Library",
    "baseUrl":""
  }
});